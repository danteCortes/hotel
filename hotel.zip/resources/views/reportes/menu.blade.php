<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#frmKardex">
  <span class="glyphicon glyphicon-plus"></span> Kardex
</button>
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#frmInventario">
  <span class="glyphicon glyphicon-plus"></span> Inventario
</button>
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#frmCierres">
  <span class="glyphicon glyphicon-plus"></span> Cierres
</button>
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#frmVentas">
  <span class="glyphicon glyphicon-plus"></span> Ventas
</button>
