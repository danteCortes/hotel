<a href="{{url('separacion')}}" class="btn btn-primary">
  <span class="glyphicon glyphicon-plus"></span> Nuevo
</a>
<a href="{{url('separacion/listar')}}" class="btn btn-primary">
  <span class="glyphicon glyphicon-list"></span> Listar
</a>
