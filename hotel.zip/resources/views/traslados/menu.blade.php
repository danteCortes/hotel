<a href="{{url('traslado/create')}}" class="btn btn-primary">
  <span class="glyphicon glyphicon-plus"></span> Nuevo
</a>
<a href="{{url('traslado')}}" class="btn btn-primary">
  <span class="glyphicon glyphicon-list"></span> Listar
</a>
