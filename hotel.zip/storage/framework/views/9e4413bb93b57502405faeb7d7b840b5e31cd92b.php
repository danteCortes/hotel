<?php $__env->startSection('estilos'); ?>
<style media="screen">
  .modal-body>.table-responsive>.table-hover tr:hover{
    background-color: #e69c2d;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
Compras
<a href="<?php echo e(url('compra/create')); ?>" class="btn btn-primary">
  <span class="glyphicon glyphicon-plus"></span> Nuevo
</a>
<a href="<?php echo e(url('compra')); ?>" class="btn btn-primary">
  <span class="glyphicon glyphicon-list"></span> Listar
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<?php echo $__env->make('plantillas.mensajes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row">
  <?php echo $__env->make('compras.frmProducto', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('compras.frmCompra', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php echo $__env->make('compras.tblDetalles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php echo $__env->make('compras.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.administrador', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>