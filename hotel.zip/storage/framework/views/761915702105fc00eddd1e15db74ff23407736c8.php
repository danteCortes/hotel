<?php $__env->startSection('titulo'); ?>
Editar Usuario
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="row">
  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
    <?php if(Session::has('correcto')): ?>
      <div class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <strong>Correcto!</strong> <?php echo e(Session::get('correcto')); ?>

      </div>
    <?php elseif(Session::has('info')): ?>
      <div class="alert alert-info alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <strong>Correcto!</strong> <?php echo e(Session::get('info')); ?>

      </div>
    <?php elseif(Session::has('error')): ?>
      <div class="alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <strong>Error!</strong> <?php echo e(Session::get('error')); ?>

      </div>
    <?php endif; ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mensaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-info alert-dismissible" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <strong>Ups!</strong> <?php echo e($mensaje); ?>

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<div class="row">
  <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
    <?php echo e(Form::open(['url'=>'cambiar-foto', 'class'=>'form-horizontal', 'enctype'=>'multipart/form-data'])); ?>

    <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title">Cambiar Foto</h3>
      </div>
      <div class="panel-body">
        <div class="img-responsive">
          <img src="<?php echo e(url('storage/usuarios/'.Auth::user()->foto)); ?>" class="img-responsive img-thumbnail" style="height:100px;">
        </div>
        <div class="form-group">
          <label class="control-label col-md-3">FOTO</label>
          <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
            <input type="file" name="foto" class="form-control" required>
          </div>
        </div>
      </div>
      <div class="panel-footer">
        <button type="submit" class="btn btn-primary">Guardar</button>
      </div>
    </div>
    <?php echo e(Form::close()); ?>

  </div>
  <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
    <?php echo e(Form::open(['url'=>'cambiar-password', 'class'=>'form-horizontal'])); ?>

    <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title">Cambiar Contraseña</h3>
      </div>
      <div class="panel-body">
        <div class="form-group">
          <label class="control-label col-md-4">Password Actual</label>
          <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
            <input type="password" name="password" class="form-control" required>
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-4">Nuevo Password</label>
          <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
            <input type="password" name="password1" class="form-control" required>
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-4">Confirmar Password</label>
          <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
            <input type="password" name="password2" class="form-control" required>
          </div>
        </div>
      </div>
      <div class="panel-footer">
        <button type="submit" class="btn btn-primary">Guardar</button>
      </div>
    </div>
    <?php echo e(Form::close()); ?>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.cajero', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>