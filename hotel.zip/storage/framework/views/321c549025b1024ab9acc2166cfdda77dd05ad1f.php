<?php if(count($cierre->creditos) > 0): ?>
<hr>
<table class="table table-condensed" id="tblResumenVentas">
  <tr>
    <th colspan="3" style="text-align:center; border-top:rgba(255, 255, 255, 0);">RESUMEN DE CREDITOS</th>
  </tr>
  <?php $__currentLoopData = $cierre->creditos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th colspan="3" style="text-align:left;">Credito Nro <?php echo e($credito->id); ?></th>
    </tr>
      <?php $__currentLoopData = $credito->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <th style="text-align:left; border-top:rgba(255, 255, 255, 0); width:20px;"><?php echo e($detalle->cantidad); ?></th>
          <th style="text-align:left; border-top:rgba(255, 255, 255, 0);"><?php echo e($detalle->producto->descripcion); ?></th>
          <th style="text-align:right; border-top:rgba(255, 255, 255, 0);"><?php echo e($detalle->total); ?></th>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th colspan="2" style="text-align:right; border-top:rgba(255, 255, 255, 0);">Total</th>
        <th style="text-align:right; border-top:rgba(255, 255, 255, 0);"><?php echo e($credito->total); ?></th>
      </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php endif; ?>
