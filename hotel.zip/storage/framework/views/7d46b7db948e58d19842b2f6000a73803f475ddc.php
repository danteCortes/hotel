<?php $__env->startSection('estilos'); ?>
<?php echo e(Html::style('bootgrid/jquery.bootgrid.min.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
Modificar Credito
<a href="<?php echo e(url('credito')); ?>" class="btn btn-primary">
  <span class="glyphicon glyphicon-plus"></span> Nuevo
</a>
<a href="<?php echo e(url('listar-creditos')); ?>" class="btn btn-primary">
  <span class="glyphicon glyphicon-list"></span> Listar
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<?php echo $__env->make('plantillas.mensajes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row">
  <?php echo $__env->make('creditos.tblProductos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('creditos.modificar.frmAgregarProducto', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php echo $__env->make('creditos.modificar.tblDetalles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('creditos.modificar.frmCredito', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php echo e(Html::script('bootgrid/jquery.bootgrid.min.js')); ?>

<?php echo $__env->make('creditos.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.cajero', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>