<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#nuevo">
  <span class="glyphicon glyphicon-plus"></span> Nuevo
</button>
<a href="<?php echo e(url('descuento/listar-todos')); ?>" class="btn btn-primary">
  <span class="glyphicon glyphicon-list"></span> Todos
</a>
<a href="<?php echo e(url('descuento/listar-vencidos')); ?>" class="btn btn-primary">
  <span class="glyphicon glyphicon-list"></span> Vencidos
</a>
<a href="<?php echo e(url('descuento/listar-vigentes')); ?>" class="btn btn-primary">
  <span class="glyphicon glyphicon-list"></span> Vigentes
</a>
