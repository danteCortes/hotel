<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Práctica de Matemáticas Discretas</title>
  </head>
  <body>
    <h1>Práctica de Matemática discretas</h1>
    <hr>
    <p>Mediante inducción matemática , verifique que cada ecuación es verdadera para todo entero positivo n.</p>
    <p>Ejercicio nro 7</p>
    <p>1/(1*3)+1/(3+5)+1/(5*7)...1/(2*n-1)(2*n+1) = n/(2*n+1)</p><br>
    <?php echo e(Form::open(['url'=>'calcular'])); ?>

      <label for="numero">Ingrese el número n: </label>
      <input type="text" name="numero" value="" id="numero" required><br><br>
      <button type="submit" name="calcular" id="calcular">Calcular</button>
    <?php echo e(Form::close()); ?>

  </body>
</html>
