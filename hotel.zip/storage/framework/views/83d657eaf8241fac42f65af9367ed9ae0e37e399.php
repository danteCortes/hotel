<?php

$prestamos = \App\Prestamo::where('cierre_id', '=', $cierre->id)->whereNull('devuelto')->where('direccion', 1)->get();

?>
<?php if(count($prestamos) > 0): ?>
<hr>
<table class="table table-condensed" id="tblPrestamosHechos">
  <tr>
    <th colspan="2" style="text-align:center; border-top:rgba(255, 255, 255, 0);">PRESTAMOS DE SALIDA</th>
  </tr>
  <?php $__currentLoopData = $prestamos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prestamo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <th colspan="3" style="text-align:left;">Prestamo Nro <?php echo e($prestamo->id); ?></th>
  </tr>
    <?php $__currentLoopData = $prestamo->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th style="text-align:left; border-top:rgba(255, 255, 255, 0);"><?php echo e($detalle->producto->codigo); ?></th>
      <th style="text-align:left; border-top:rgba(255, 255, 255, 0);"><?php echo e($detalle->producto->descripcion); ?></th>
      <th style="text-align:right; border-top:rgba(255, 255, 255, 0);"><?php echo e($detalle->cantidad); ?></th>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php endif; ?>
