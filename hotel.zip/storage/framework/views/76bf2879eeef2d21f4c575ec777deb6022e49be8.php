<div class="row oculto" id="fichaVentas">
  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
    <div class="table-responsive" id="imprimirVentas">
      <table class="table table-bordered table-condensed" id="resumen-ventas">
      </table>
    </div>
    <button type="button" class="btn btn-primary" id="imprimir-ventas"><span class="fa fa-print"></span> Imprimir</button>
    <a href="<?php echo e(url('reporte')); ?>" class="btn btn-default"> Salir</a>
  </div>
</div>
