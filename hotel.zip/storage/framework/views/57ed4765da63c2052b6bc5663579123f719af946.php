<?php $__env->startSection('estilos'); ?>
<?php echo e(Html::style('bootgrid/jquery.bootgrid.min.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
Nuevo Traslado
<?php echo $__env->make('traslados.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<?php echo $__env->make('plantillas.mensajes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row">
  <?php echo $__env->make('traslados.tblProductos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('traslados.nuevo.frmAgregarDetalle', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php if($counttraslados > 0 ): ?>
<div class="row">
  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
    <div class="table-responsive">
      <table class="table table-condensed table-bordered" style="background-color:#bfbfbf;">
        <thead>
          <tr>
            <th>Operación</th>
            <th>Cantidad</th>
            <th>Cod. Producto</th>
            <th>Descripción</th>
          </tr>
        </thead>
        <tbody id="detalles">
        	<?php $__currentLoopData = $traslados->detalle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        	<tr>
        		<td class="text-center">
        			<?php echo e(Form::open(['url'=>'traslado/'.$detall->id, 'method'=>'delete', 'class'=>'pull-left'])); ?>

                    <?php echo e(csrf_field()); ?>

                    	<?php echo e(Form::hidden('cantidad', $detall->cantidad, ['id'=>'cantidad'])); ?>

                    	<?php echo e(Form::hidden('producto_codigo', $detall->producto_codigo, ['id'=>'producto_codigo'])); ?>

                    	<button class="btn btn-xs btn-danger del" title="<?php echo e($detall->id); ?>">Quitar</button>
                    <?php echo e(Form::close()); ?>

                </td>
                <td><?php echo e($detall->cantidad); ?></td>
                <td><?php echo e($detall->producto_codigo); ?></td>
                <td><?php echo e($detall->producto->descripcion); ?></td>
        	</tr>
        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <!-- <tr>
            <td colspan="4"><strong class="pull-right">CANTIDAD TOTAL DE PRODUCTOS TRASLADADOS: </strong></td>
          </tr> -->
        </tbody>
      </table>
    </div>
  </div>
</div>
<div class="row">
  <?php echo e(Form::open(['url'=>'traslado/terminar', 'method'=>'POST'])); ?>

  <?php echo e(csrf_field()); ?>

	  <?php echo e(Form::hidden('id_traslado', $traslados->id, ['id'=>'id_traslado'])); ?>

	  <div class="col-sm-4">
	  	<select name="tienda_traslado" id="tienda_traslado" class="form-control" required>
	  		<option value>-- Seleccione una Tienda --</option>
	  		<?php $__currentLoopData = $tiendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tienda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  			<option value="<?php echo e($tienda->id); ?>"><?php echo e($tienda->nombre); ?></option>
	  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  	</select>
	  </div>
	  <div class="col-sm-8">
	    <button type="submit" class="btn btn-primary"><span class="fa fa-check-square-o"> </span> Terminar</button>
	    <button type="button" class="btn btn-danger pull-right"><span class="fa fa-times"> </span> Cancelar</button>
	  </div>
  <?php echo e(Form::close()); ?>

</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <?php echo e(Html::script('bootgrid/jquery.bootgrid.min.js')); ?>

	<?php echo e(Html::script('assets/lib/mask/jquery.mask.js')); ?>

	<?php echo $__env->make('traslados.nuevo.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.cajero', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>