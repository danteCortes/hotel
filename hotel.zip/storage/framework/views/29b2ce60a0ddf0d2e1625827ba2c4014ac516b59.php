<?php $__env->startSection('alertas'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
Administrador
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
<li class="">
  <a href="<?php echo e(url('hotel')); ?>">
    <i class="fa fa-home"></i><span class="link-title">&nbsp;Hotel</span>
  </a>
</li>
<li class="">
  <a href="<?php echo e(url('edificio')); ?>">
    <i class="fa fa-building"></i><span class="link-title">&nbsp;Edificios</span>
  </a>
</li>
<li class="">
  <a href="<?php echo e(url('habitacion')); ?>">
    <i class="fa fa-hotel"></i><span class="link-title">&nbsp;Habitaciones</span>
  </a>
</li>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>