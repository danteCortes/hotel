<?php
// Primero calculamos todos los dolares que se recibieron y lo convertimos a soles.
$pagos = \DB::table('pagos')->where('cierre_id', $cierre->id)->whereNotNull('credito_id')->get();

?>
<?php if(count($pagos) > 0): ?>
<hr>
<table class="table table-condensed" id="tblPagosCreditos">
  <tr>
    <th colspan="2" style="text-align:center; border-top:rgba(255, 255, 255, 0);">PAGOS DE CRÉDITOS</th>
  </tr>
  <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th style="text-align:left; border-top:rgba(255, 255, 255, 0);">Crédito Nro <?php echo e($pago->credito_id); ?> </th>
      <th style="text-align:right; border-top:rgba(255, 255, 255, 0);"><?php echo e(number_format($pago->monto, 2, '.', ' ')); ?></th>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php endif; ?>
