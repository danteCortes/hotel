<?php $__env->startSection('alertas'); ?>
  <?php echo $__env->make('plantillas.alertas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
Administrador
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
<li class="">
  <a href="<?php echo e(url('tienda')); ?>">
    <i class="fa fa-home"></i><span class="link-title">&nbsp;Tiendas</span>
  </a>
</li>
<li class="">
  <a href="<?php echo e(url('usuario')); ?>">
    <i class="fa fa-users"></i><span class="link-title">&nbsp;Usuarios</span>
  </a>
</li>
<li class="">
  <a href="<?php echo e(url('producto')); ?>">
    <i class="fa fa-shopping-bag"></i><span class="link-title">&nbsp;Productos</span>
  </a>
</li>
<li class="">
  <a href="<?php echo e(url('compra')); ?>">
    <i class="fa fa-money"></i><span class="link-title">&nbsp;Compras</span>
  </a>
</li>
<li class="">
  <a href="<?php echo e(url('proveedor')); ?>">
    <i class="fa fa-user-circle"></i><span class="link-title">&nbsp;Proveedores</span>
  </a>
</li>
<li class="">
  <a href="<?php echo e(url('tarjeta')); ?>">
    <i class="fa fa-credit-card"></i><span class="link-title">&nbsp;Tarjetas</span>
  </a>
</li>
<li class="">
  <a href="<?php echo e(url('descuento/listar-todos')); ?>">
    <i class="fa fa-tags"></i><span class="link-title">&nbsp;Descuentos</span>
  </a>
</li>
<li class="">
  <a href="<?php echo e(url('reporte')); ?>">
    <i class="fa fa-file"></i><span class="link-title">&nbsp;Reportes</span>
  </a>
</li>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>