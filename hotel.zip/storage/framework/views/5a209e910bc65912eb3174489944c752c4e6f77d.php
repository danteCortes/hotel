<?php
$productos = \DB::table('detalles')->join('creditos', 'creditos.id', '=', 'detalles.credito_id')
  ->join('productos', 'productos.codigo', '=', 'detalles.producto_codigo')
  ->where('creditos.cierre_id', $cierre->id)->select(
    'productos.codigo as codigo',
    DB::raw("SUM(detalles.cantidad) as cantidad"),
    'productos.descripcion as descripcion'
    )->groupBy('productos.codigo', 'productos.descripcion')->get();
 ?>
 <?php if(count($productos) > 0): ?>
<hr>
<table class="table table-condensed" id="tblVentasProductos">
  <tr>
    <th colspan="3" style="text-align:center; border-top:rgba(255, 255, 255, 0);">RESUMEN DE CRÉDITOS POR PRODUCTOS</th>
  </tr>
  <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th style="text-align:left; border-top:rgba(255, 255, 255, 0);"><?php echo e($producto->codigo); ?></th>
      <th style="text-align:left; border-top:rgba(255, 255, 255, 0);"><?php echo e($producto->descripcion); ?></th>
      <th style="text-align:right; border-top:rgba(255, 255, 255, 0);"><?php echo e($producto->cantidad); ?></th>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php endif; ?>
