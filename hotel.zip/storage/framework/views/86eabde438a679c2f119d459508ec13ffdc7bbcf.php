<?php $__env->startSection('estilos'); ?>
<?php echo e(Html::style('bootgrid/jquery.bootgrid.min.css')); ?>

<style media="screen">
  .operaciones{
    width: 207px;
  }
  .rojo{
    background-color: #ff0000;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
  Hotel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
  <?php echo $__env->make('plantillas.mensajes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="text-center">
    <?php $__currentLoopData = \App\Edificio::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edificio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a class="quick-btn btn btn-primary" href="<?php echo e(url('hotel/edificio/'.$edificio->id)); ?>">
      <i class="fa fa-building-o fa-2x"></i>
      <span><?php echo e($edificio->nombre); ?></span>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div><hr>
  <div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
      <div class="table-responsive" id="imprimir-tabla">
        <table class="table table-hover table-condensed table-bordered" id="tblHabitaciones">
          <thead>
            <tr class="info">
              <th data-column-id="numero" data-formatter="alertas" data-width="77px;">Numero</th>
              <th data-column-id="edificio" data-order="asc">Edificio</th>
              <th data-column-id="huesped">Huesped</th>
              <th data-column-id="televisor">Televisor</th>
              <th data-column-id="precio">Precio</th>
              <th data-column-id="commands" data-formatter="commands" data-sortable="false" data-width="207px;">Operaciones</th>
            </tr>
          </thead>
        </table>
      </div>
      <button type="button" class="btn btn-primary imprimir">Imprimir</button>
    </div>
  </div>
  <?php echo $__env->make('hotel.modales.registrar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('hotel.modales.ver', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('hotel.modales.editar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="modal fade" id="error" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header" style="background-color:#bb0000; color:#fff;">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title" id="myModalLabel">HABITACIÓN OCUPADA</h4>
        </div>
        <div class="modal-body" style="background-color:#e69c2d">
          <div class="panel" style="background-color:#bd7406">
            <div class="panel-body">
              <p>LA HABITACIÓN <strong id="numero_error"></strong> DEL EDIFICIO
                <strong id="edificio_error"></strong>, SE ENCUENTRA OCUPADO, VUELVA A INTENTARLO O DESOCUPE LA HABITACIÓN,
                INGRESANDO EL PAGO POR LA HABITACIÓN Y HACIENDO EL CAMBIO RESPECTIVO.</p>
            </div>
          </div>
        </div>
        <div class="modal-footer" style="background-color:#bb0000">
          <button type="button" class="btn btn-default" data-dismiss="modal">
            <span class="glyphicon glyphicon-ban-circle"></span> Cancelar</button>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <?php echo e(Html::script('bootgrid/jquery.bootgrid.min.js')); ?>

  <?php echo e(Html::script('assets/js/jquery.printarea.js')); ?>

  <?php echo $__env->make('hotel.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.administrador', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>