<div class="row">
  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
    <div class="panel panel-default">
      <div class="panel-body" style="background-color:#bfbfbf;">
        <?php echo e(Form::open(['url'=>'terminar-cambio'])); ?>

        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
            <div class="form-group">
              <div class="input-group">
                <?php if($persona = $venta->recibo->persona): ?>
                  <input type="text" name="documento" class="form-control" placeholder="DNI/RUC" data-mask="99999999999"
                    value="<?php echo e($persona->dni); ?>" id="documento" readonly>
                <?php elseif($empresa = $venta->recibo->empresa): ?>
                  <input type="text" name="documento" class="form-control" placeholder="DNI/RUC" data-mask="99999999999"
                    value="<?php echo e($empresa->ruc); ?>" id="documento" readonly>
                <?php else: ?>
                  <input type="text" name="documento" class="form-control" placeholder="DNI/RUC" data-mask="99999999999" id="documento"
                    readonly>
                <?php endif; ?>
                <span class="input-group-btn">
                  <button class="btn btn-default" type="button"><span class="fa fa-search"></span></button>
                </span>
              </div>
            </div>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-6 col-lg-8">
            <div class="form-group">
              <?php if($empresa = $venta->recibo->empresa): ?>
                <input type="text" name="nombre" class="form-control mayuscula" placeholder="RAZÓN SOCIAL" id="nombre" readonly
                  value="<?php echo e($empresa->nombre); ?>">
              <?php else: ?>
                <input type="text" name="nombre" class="form-control mayuscula" placeholder="RAZÓN SOCIAL" id="nombre" readonly>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
            <div class="form-group">
              <?php if($persona = $venta->recibo->persona): ?>
                <input type="text" name="nombres" class="form-control mayuscula" placeholder="NOMBRES" id="nombres" readonly
                  value="<?php echo e($persona->nombres); ?>">
              <?php else: ?>
                <input type="text" name="nombres" class="form-control mayuscula" placeholder="NOMBRES" id="nombres" readonly>
              <?php endif; ?>
            </div>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
            <div class="form-group">
              <?php if($persona = $venta->recibo->persona): ?>
                <input type="text" name="apellidos" class="form-control mayuscula" placeholder="APELLIDOS" id="apellidos" readonly
                  value="<?php echo e($persona->apellidos); ?>">
              <?php else: ?>
                <input type="text" name="apellidos" class="form-control mayuscula" placeholder="APELLIDOS" id="apellidos" readonly>
              <?php endif; ?>
            </div>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-4 col-lg-6">
            <div class="form-group">
              <?php if($persona = $venta->recibo->persona): ?>
                <input type="text" name="direccion" class="form-control mayuscula" placeholder="DIRECCIÓN" id="direccion" readonly
                  value="<?php echo e($persona->direccion); ?>">
              <?php elseif($empresa = $venta->recibo->empresa): ?>
                <input type="text" name="direccion" class="form-control mayuscula" placeholder="DIRECCIÓN" id="direccion" readonly
                  value="<?php echo e($empresa->direccion); ?>">
              <?php else: ?>
                <input type="text" name="direccion" class="form-control mayuscula" placeholder="DIRECCIÓN" id="direccion" readonly>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
            <div class="form-group">
              <input type="text" name="soles" class="form-control moneda" placeholder="SOLES" id="efectivo">
            </div>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
            <div class="form-group">
              <div class="input-group">
                <input type="text" name="dolares" class="form-control moneda" placeholder="DOLARES" id="dolares">
                <span class="input-group-btn">
                  <button class="btn btn-default" type="button" id="btnTipoCambio">Tipo Cambio</button>
                </span>
              </div>
            </div>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
            <div class="form-group">
              <div class="input-group">
                <?php if($cambio = \App\Cambio::where('venta_id', $venta->id)->first()): ?>
                  <?php if($pagoTarjeta = \App\TarjetaVenta::where('cambio_id', $cambio->id)->first()): ?>
                    <input type="text" name="tarjeta" class="form-control moneda" placeholder="TARJETA" id="tarjeta" value="<?php echo e($pagoTarjeta->monto); ?>">
                  <?php else: ?>
                    <input type="text" name="tarjeta" class="form-control moneda" placeholder="TARJETA" id="tarjeta">
                  <?php endif; ?>
                <?php endif; ?>
                <span class="input-group-btn">
                  <button class="btn btn-default" type="button" id="btnRegistrarTarjeta">Registrar</button>
                </span>
              </div>
            </div>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
            <div class="form-group">
              <?php if($cambio = $venta->cambio): ?>
                <input type="text" name="vuelto" class="form-control" value="<?php echo e(number_format($cambio->diferencia, 2, '.', ' ')); ?>" placeholder="VUELTO" readonly id="vuelto">
              <?php else: ?>
                <input type="text" name="vuelto" class="form-control" placeholder="VUELTO" readonly id="vuelto">
              <?php endif; ?>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
            <input type="hidden" name="venta_id" value="<?php echo e($venta->id); ?>" id="venta_id">
            <button type="submit" class="btn btn-primary">Terminar</button>
            <button type="button" class="btn btn-warning">Cancelar</button>
          </div>
        </div>
        <?php echo e(Form::close()); ?>

      </div>
    </div>
  </div>
</div>
