<?php $__env->startSection('estilos'); ?>
<style media="screen">
  .modal-body>.table-responsive>.table-hover tr:hover{
    background-color: #e69c2d;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
Usuarios
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#nuevo">
  <span class="glyphicon glyphicon-plus"></span> Nuevo
</button>
<div class="modal fade" id="nuevo" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <?php echo e(Form::open(['url'=>'usuario', 'enctype'=>'multipart/form-data'])); ?>

      <?php echo e(csrf_field()); ?>

      <div class="modal-header" style="background-color:#385a94; color:#fff;">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">NUEVO USUARIO</h4>
      </div>
      <div class="modal-body" style="background-color:#e69c2d">
        <div class="panel" style="background-color:#bd7406">
          <div class="panel-body">
            <div class="form-group">
              <input type="text" data-mask="99999999" class="form-control input-sm" placeholder="DNI*" required name="dni">
            </div>
            <div class="form-group">
              <input type="text" class="form-control mayuscula input-sm" placeholder="NOMBRES*" required name="nombres">
            </div>
            <div class="form-group">
              <input type="text" class="form-control mayuscula input-sm" placeholder="APELLIDOS*" required name="apellidos">
            </div>
            <div class="form-group">
              <input type="text" class="form-control mayuscula input-sm" placeholder="DIRECCIÓN" name="direccion">
            </div>
            <div class="form-group">
              <input type="text" data-mask="999999999" class="form-control input-sm" placeholder="TELÉFONO" name="telefono">
            </div>
            <div class="form-group">
              <select class="form-control" name="tipo" required>
                <option value=>SELECCIONAR TIPO</option>
                <option value="1">ADMINISTRADOR</option>
                <option value="2">CAJERO</option>
              </select>
            </div>
            <div class="form-group">
              <select class="form-control" name="tienda_id">
                <option value=>SELECCIONAR TIENDA</option>
                <?php $__currentLoopData = \App\Tienda::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tienda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($tienda->id); ?>"><?php echo e($tienda->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="form-group">
              <input type="file" class="form-control mayuscula input-sm" name="foto">
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer" style="background-color:#385a94">
        <button type="button" class="btn btn-default" data-dismiss="modal">
          <span class="glyphicon glyphicon-ban-circle"></span> Cancelar</button>
        <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Guardar</button>
      </div>
      <?php echo e(Form::close()); ?>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="row">
  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
    <?php if(Session::has('correcto')): ?>
      <div class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <strong>Correcto!</strong> <?php echo e(Session::get('correcto')); ?>

      </div>
    <?php elseif(Session::has('info')): ?>
      <div class="alert alert-info alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <strong>Correcto!</strong> <?php echo e(Session::get('info')); ?>

      </div>
    <?php elseif(Session::has('error')): ?>
      <div class="alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <strong>Error!</strong> <?php echo e(Session::get('error')); ?>

      </div>
    <?php endif; ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mensaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-info alert-dismissible" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <strong>Ups!</strong> <?php echo e($mensaje); ?>

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<div class="row">
  <div class="col-xs-12 col-sm-12 col-md-8 col-md-offset-2 col-lg-6 col-lg-offset-3">
    <div class="table-responsive">
      <table class="table table-condensed table-hover table-bordered">
        <thead>
          <tr style="background-color:#385a94; color:#FFF;">
            <th>DNI</th>
            <th>USUARIO</th>
            <th>OPERACIONES</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = App\Usuario::where('id', '!=', Auth::user()->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($usuario->persona->dni); ?></td>
              <td><?php echo e($usuario->persona->nombres); ?> <?php echo e($usuario->persona->apellidos); ?></td>
              <td>
                <button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#ver<?php echo e($usuario->id); ?>">
                  <span class="fa fa-eye"></span>
                </button>
                <div class="modal fade" id="ver<?php echo e($usuario->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header" style="background-color:#31b0d5; color:#fff;">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">VER USUARIO</h4>
                      </div>
                      <div class="modal-body" style="background-color:#e69c2d">
                        <div class="img-resposive" style="text-align:center">
                          <img src="<?php echo e(url('storage/usuarios/'.$usuario->foto)); ?>" alt="" class="img-responsive img-thumbnail" style="height:100px;">
                        </div>
                        <div class="table-responsive" style="background-color:#bd7406">
                          <table class="table table-condensed table-bordered table-hover" style="margin:0px; background-color:#bd7406; color:#ff;">
                            <tr>
                              <th>DNI: </th>
                              <td><?php echo e($usuario->persona->dni); ?></td>
                            </tr>
                            <tr>
                              <th>Nombres: </th>
                              <td><?php echo e($usuario->persona->nombres); ?></td>
                            </tr>
                            <tr>
                              <th>Apellidos: </th>
                              <td><?php echo e($usuario->persona->apellidos); ?></td>
                            </tr>
                            <tr>
                              <th>Dirección: </th>
                              <td><?php echo e($usuario->persona->direccion); ?></td>
                            </tr>
                            <tr>
                              <th>Teléfono: </th>
                              <td><?php echo e($usuario->persona->telefono); ?></td>
                            </tr>
                            <tr>
                              <th>Tipo: </th>
                              <td>
                                <?php if($usuario->tipo == 1): ?>
                                  ADMINISTRADOR
                                <?php else: ?>
                                  CAJERO
                                <?php endif; ?>
                              </td>
                            </tr>
                            <tr>
                              <th>Tienda: </th>
                              <td><?php echo e($usuario->tienda ? $usuario->tienda->nombre : ''); ?></td>
                            </tr>
                          </table>
                        </div>
                      </div>
                      <div class="modal-footer" style="background-color:#31b0d5">
                        <button type="button" class="btn btn-default" data-dismiss="modal">
                          <span class="glyphicon glyphicon-remove"></span> Cerrar</button>
                      </div>
                    </div>
                  </div>
                </div>
                <button type="button" class="btn btn-warning btn-xs" data-toggle="modal" data-target="#editar<?php echo e($usuario->id); ?>">
                  <span class="glyphicon glyphicon-edit"></span>
                </button>
                <div class="modal fade" id="editar<?php echo e($usuario->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <?php echo e(Form::open(['url'=>'usuario/'.$usuario->id, 'method'=>'put', 'enctype'=>'multipart/form-data'])); ?>

                      <?php echo e(csrf_field()); ?>

                      <div class="modal-header" style="background-color:#385a94; color:#fff;">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">MODIFICAR USUARIO</h4>
                      </div>
                      <div class="modal-body" style="background-color:#e69c2d">
                        <div class="img-resposive" style="text-align:center">
                          <img src="<?php echo e(url('storage/usuarios/'.$usuario->foto)); ?>" alt="" class="img-responsive img-thumbnail" style="height:100px;">
                        </div>
                        <div class="panel" style="background-color:#bd7406">
                          <div class="panel-body">
                            <div class="form-group">
                              <input type="text" data-mask="99999999" class="form-control input-sm" placeholder="DNI*" required name="dni" value="<?php echo e($usuario->persona->dni); ?>">
                            </div>
                            <div class="form-group">
                              <input type="text" class="form-control mayuscula input-sm" placeholder="NOMBRES*" required name="nombres" value="<?php echo e($usuario->persona->nombres); ?>">
                            </div>
                            <div class="form-group">
                              <input type="text" class="form-control mayuscula input-sm" placeholder="APELLIDOS*" required name="apellidos" value="<?php echo e($usuario->persona->apellidos); ?>">
                            </div>
                            <div class="form-group">
                              <input type="text" class="form-control mayuscula input-sm" placeholder="DIRECCIÓN" name="direccion" value="<?php echo e($usuario->persona->direccion); ?>">
                            </div>
                            <div class="form-group">
                              <input type="text" data-mask="999999999" class="form-control input-sm" placeholder="TELÉFONO" name="telefono" value="<?php echo e($usuario->persona->telefono); ?>">
                            </div>
                            <div class="form-group">
                              <select class="form-control" name="tipo" required>
                                  <option value="<?php echo e($usuario->tipo); ?>">
                                    <?php if($usuario->tipo == 1): ?>
                                      ADMINISTRADOR (ACTUAL)
                                    <?php else: ?>
                                      CAJERO (ACTUAL)
                                    <?php endif; ?>
                                  </option>
                                <option value="">SELECCIONAR TIPO</option>
                                <option value="1">ADMINISTRADOR</option>
                                <option value="2">CAJERO</option>
                              </select>
                            </div>
                            <div class="form-group">
                              <select class="form-control" name="tienda_id">
                                  <option value="<?php echo e($usuario->tienda_id); ?>">
                                    <?php echo e(($usuario->tienda) ? $usuario->tienda->nombre : 'SELECCIONAR TIENDA '); ?> (ACTUAL)
                                  </option>
                                <option value=>SELECCIONAR TIENDA</option>
                                <?php $__currentLoopData = \App\Tienda::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tienda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($tienda->id); ?>"><?php echo e($tienda->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                            </div>
                            <div class="form-group">
                              <input type="file" class="form-control mayuscula input-sm" name="foto">
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer" style="background-color:#385a94">
                        <button type="button" class="btn btn-default" data-dismiss="modal">
                          <span class="glyphicon glyphicon-ban-circle"></span> Cancelar</button>
                        <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Modificar</button>
                      </div>
                      <?php echo e(Form::close()); ?>

                    </div>
                  </div>
                </div>
                <button type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#eliminar<?php echo e($usuario->id); ?>">
                  <span class="glyphicon glyphicon-trash"></span>
                </button>
                <div class="modal fade" id="eliminar<?php echo e($usuario->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <?php echo e(Form::open(['url'=>'usuario/'.$usuario->id, 'method'=>'delete'])); ?>

                      <?php echo e(csrf_field()); ?>

                      <div class="modal-header" style="background-color:#bb0000; color:#fff;">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">ELIMINAR USUARIO</h4>
                      </div>
                      <div class="modal-body" style="background-color:#e69c2d">
                        <div class="panel" style="background-color:#bd7406">
                          <div class="panel-body">
                            <p>ESTA A PUNTO DE ELIMINAR AL USUARIO <?php echo e($usuario->persona->nombres); ?>, CON ESTA ACCIÓN ELIMINARÁ TODOS
                              LOS REGISTROS RELACIONADOS CON ESTE USUARIO.</p>
                            <p>SI QUIERE CONTINUAR CON ESTA ACCIÓN HAGA CLIC EN EL BOTÓN ELIMINAR, DE LO CONTRARIO, EN EL BOTÓN
                              CANCELAR.</p>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer" style="background-color:#bb0000">
                        <button type="button" class="btn btn-default" data-dismiss="modal">
                          <span class="glyphicon glyphicon-ban-circle"></span> Cancelar</button>
                        <button type="submit" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Eliminar</button>
                      </div>
                      <?php echo e(Form::close()); ?>

                    </div>
                  </div>
                </div>
                <!--Botón para mostrar un modal de advertencia antes de restaurar la contraseña del usuario.-->
                <!--Fecha: 16/09/2017-->
                <button type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#restaurar<?php echo e($usuario->id); ?>">
                  <span class="glyphicon glyphicon-refresh"></span>
                </button>
                <!--Modal de advertencia para restaurar la contraseña del usuario. Contiene un formuario que envia el id del
                  usuario al que se le va a resturar al método restaurarContraseña del controlador UsuarioController.-->
                <!--Fecha: 16/09/2017-->
                <div class="modal fade" id="restaurar<?php echo e($usuario->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <?php echo e(Form::open(['url'=>'restaurar-contrasenia'])); ?>

                      <?php echo e(csrf_field()); ?>

                      <div class="modal-header" style="background-color:#449d44; color:#fff;">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">RESTAURAR CONTRASEÑA</h4>
                      </div>
                      <div class="modal-body" style="background-color:#e69c2d">
                        <div class="panel" style="background-color:#bd7406">
                          <div class="panel-body">
                            <p style="color:#fff;">ESTA A PUNTO DE RESTAURAR LA CONTRASEÑA AL USUARIO <strong><?php echo e($usuario->persona->nombres); ?></strong>,
                              CON ESTA ACCIÓN LA CONTRASEÑA DEL USUARIO VOLVERÁ A SER SU NÚMERO DE DNI, NO OLVIDE INFORMAR AL USUARIO EN CUESTIÓN DE
                              ESTE CAMBIO.</p>
                            <p style="color:#fff;">SI QUIERE CONTINUAR CON ESTA ACCIÓN HAGA CLIC EN EL BOTÓN RESTAURAR, DE LO CONTRARIO, EN EL BOTÓN
                              CANCELAR.</p>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer" style="background-color:#449d44">
                        <?php echo e(Form::hidden('usuario_id', $usuario->id)); ?>

                        <button type="button" class="btn btn-default" data-dismiss="modal">
                          <span class="glyphicon glyphicon-ban-circle"></span> Cancelar</button>
                        <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-refresh"></span> Restaurar</button>
                      </div>
                      <?php echo e(Form::close()); ?>

                    </div>
                  </div>
                </div>
                <?php if($usuario->tipo != 1): ?>
                  <?php if(!$usuario->estado_caja): ?>
                    <!--Botón para mostrar un modal de advertencia antes de abrir caja  al usuario.-->
                    <!--Fecha: 16/09/2017-->
                    <button type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#abrir<?php echo e($usuario->id); ?>"
                      style="background-color:#fff; border-color:black; color:#000;">
                      <span class="fa fa-upload"></span>
                    </button>
                    <!--Modal de advertencia para abrir caja al usuario. Contiene un formuario que envia el id del
                      usuario al que se le va a abrir caja al método abrirCaja del controlador UsuarioController.-->
                    <!--Fecha: 16/09/2017-->
                    <div class="modal fade" id="abrir<?php echo e($usuario->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <?php echo e(Form::open(['url'=>'abrir-caja'])); ?>

                        <?php echo e(csrf_field()); ?>

                        <div class="modal-header" style="background-color:#dddddd; color:#000;">
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                          <h4 class="modal-title" id="myModalLabel">ABRIR CAJA</h4>
                        </div>
                        <div class="modal-body" style="background-color:#e69c2d">
                          <div class="panel" style="background-color:#bd7406">
                            <div class="panel-body">
                              <p style="color:#fff;">ESTA A PUNTO DE ABRIR CAJA AL USUARIO <strong><?php echo e($usuario->persona->nombres); ?></strong>,
                                CON ESTA ACCIÓN EL USUARIO PODRÁ REALIZAR OPERACIONES EN SU TIENDA ASIGNADA, NO OLVIDE INFORMAR AL USUARIO EN
                                CUESTIÓN DE ESTE CAMBIO.</p>
                              <p style="color:#fff;">SI QUIERE CONTINUAR CON ESTA ACCIÓN HAGA CLIC EN EL BOTÓN ABRIR CAJA, DE LO CONTRARIO, EN EL BOTÓN
                                CANCELAR.</p>
                            </div>
                          </div>
                        </div>
                        <div class="modal-footer" style="background-color:#dddddd">
                          <?php echo e(Form::hidden('usuario_id', $usuario->id)); ?>

                          <button type="button" class="btn btn-default" data-dismiss="modal">
                            <span class="glyphicon glyphicon-ban-circle"></span> Cancelar</button>
                          <button type="submit" class="btn btn-primary"><span class="fa fa-upload"></span> Abrir Caja</button>
                        </div>
                        <?php echo e(Form::close()); ?>

                      </div>
                    </div>
                  </div>
                  <?php else: ?>
                    <!--Botón para mostrar un modal de advertencia antes de cerrar caja  al usuario.-->
                    <!--Fecha: 16/09/2017-->
                    <button type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#cerrar<?php echo e($usuario->id); ?>"
                      style="background-color:#fff; border-color:black; color:#000;">
                      <span class="fa fa-download"></span>
                    </button>
                    <!--Modal de advertencia para cerrar caja al usuario. Contiene un formuario que envia el id del
                      usuario al que se le va a cerrar caja al método cerrarCaja del controlador UsuarioController.-->
                    <!--Fecha: 16/09/2017-->
                    <div class="modal fade" id="cerrar<?php echo e($usuario->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <?php echo e(Form::open(['url'=>'abrir-caja'])); ?>

                        <?php echo e(csrf_field()); ?>

                        <div class="modal-header" style="background-color:#dddddd; color:#000;">
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                          <h4 class="modal-title" id="myModalLabel">CERRAR CAJA</h4>
                        </div>
                        <div class="modal-body" style="background-color:#e69c2d">
                          <div class="panel" style="background-color:#bd7406">
                            <div class="panel-body">
                              <p style="color:#fff;">ESTA A PUNTO DE CERRAR CAJA AL USUARIO <strong><?php echo e($usuario->persona->nombres); ?></strong>,
                                CON ESTA ACCIÓN EL USUARIO YA NO PODRÁ REALIZAR OPERACIONES EN SU TIENDA ASIGNADA, NO OLVIDE INFORMAR AL USUARIO EN
                                CUESTIÓN DE ESTE CAMBIO.</p>
                              <p style="color:#fff;">SI QUIERE CONTINUAR CON ESTA ACCIÓN HAGA CLIC EN EL BOTÓN CERRAR CAJA, DE LO CONTRARIO, EN EL BOTÓN
                                CANCELAR.</p>
                            </div>
                          </div>
                        </div>
                        <div class="modal-footer" style="background-color:#dddddd">
                          <?php echo e(Form::hidden('usuario_id', $usuario->id)); ?>

                          <button type="button" class="btn btn-default" data-dismiss="modal">
                            <span class="glyphicon glyphicon-ban-circle"></span> Cancelar</button>
                          <button type="submit" class="btn btn-primary"><span class="fa fa-download"></span> Cerrar Caja</button>
                        </div>
                        <?php echo e(Form::close()); ?>

                      </div>
                    </div>
                  </div>
                  <?php endif; ?>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.administrador', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>