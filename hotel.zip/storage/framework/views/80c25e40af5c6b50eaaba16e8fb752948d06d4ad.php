<?php $__env->startSection('estilos'); ?>
<?php echo e(Html::style('bootgrid/jquery.bootgrid.min.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
Prestamos
<a href="<?php echo e(url('prestamo')); ?>" class="btn btn-primary">
  <span class="glyphicon glyphicon-plus"></span> Nuevo
</a>
<a href="<?php echo e(url('prestamo/listar')); ?>" class="btn btn-primary">
  <span class="glyphicon glyphicon-list"></span> Listar
</a>
<a href="<?php echo e(url('prestamo/listar-devolver')); ?>" class="btn btn-primary">
  <span class="glyphicon glyphicon-list"></span> Devolver
</a>
<a href="<?php echo e(url('prestamo/listar-pedir')); ?>" class="btn btn-primary">
  <span class="glyphicon glyphicon-list"></span> Recoger
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<?php echo $__env->make('plantillas.mensajes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row">
  <?php echo $__env->make('prestamos.tblProductos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('prestamos.nuevo.frmAgregarProducto', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php echo $__env->make('prestamos.nuevo.tblDetalles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('prestamos.nuevo.frmPrestamo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php echo e(Html::script('bootgrid/jquery.bootgrid.min.js')); ?>

<?php echo $__env->make('prestamos.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.cajero', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>