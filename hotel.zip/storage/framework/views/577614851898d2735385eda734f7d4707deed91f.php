<?php
  $cambios = \DB::table('cambios')->join('ventas', 'ventas.id', '=', 'cambios.venta_id')
    ->join('recibos', 'ventas.id', '=', 'recibos.venta_id')
    ->where('cambios.cierre_id', $cierre->id)
    ->where('ventas.cierre_id', '!=', $cierre->id)
    ->select(
      'recibos.numeracion as numeracion',
      'ventas.created_at as fecha_venta',
      'cambios.diferencia as diferencia'
    )->get();

 ?>
<?php if(count($cambios) > 0): ?>
<hr style="margin-bottom: 1px; margin-top: 0px;">
<table class="table table-condensed" id="tblResumenVentas" style="margin-bottom:0px;">
  <tr>
    <th colspan="3" style="text-align:center; border-top:rgba(255, 255, 255, 0);">
      <p class="text-center" style="font-size: 12px; margin-bottom:1px;">RESUMEN DE CAMBIOS</p></th>
  </tr>
  <?php $__currentLoopData = $cambios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cambio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td style="border-top:rgba(130, 130, 130, 0.5); padding-top:1px; padding-bottom:0px;">
        <p class="text-left" style="font-size: 12px; margin-bottom:1px;"><?php echo e($cambio->numeracion); ?></p></td>
      <td style="border-top:rgba(130, 130, 130, 0.5); padding-top:1px; padding-bottom:0px;">
        <p class="text-left" style="font-size: 12px; margin-bottom:1px;">
          <?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $cambio->fecha_venta)->format('d/m/Y')); ?></p></td>
      <td style="border-top:rgba(130, 130, 130, 0.5); padding-top:1px; padding-bottom:0px;">
        <p class="text-right" style="font-size: 12px; margin-bottom:1px;"><?php echo e(number_format($cambio->diferencia, 2, '.', ' ')); ?></p></td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php endif; ?>
