<?php $__env->startSection('estilos'); ?>
<?php echo e(Html::style('bootgrid/jquery.bootgrid.min.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
Producto
<?php echo $__env->make('productos.nuevo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<?php echo $__env->make('plantillas.mensajes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row">
  <div class="col-xs-12 col-sm-12 col-md-10 col-md-offset-1 col-lg-10 col-lg-offset-1">
    <div class="table-responsive">
      <table class="table table-hover table-condensed table-bordered" id="tblProductos">
        <thead>
          <tr class="info">
            <th data-column-id="codigo" data-order="desc">Código</th>
            <th data-column-id="descripcion">Descripción</th>
            <th data-column-id="precio">Precio Venta</th>
            <th data-column-id="commands" data-formatter="commands" data-sortable="false">Operaciones</th>
          </tr>
        </thead>
      </table>
    </div>
  </div>
</div>
<?php echo $__env->make('productos.modales', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php echo e(Html::script('bootgrid/jquery.bootgrid.min.js')); ?>

<?php echo e(Html::script('assets/js/jquery.printarea.js')); ?>

<?php echo $__env->make('productos.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.administrador', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>