<?php $__env->startSection('estilos'); ?>
<?php echo e(Html::style('bootgrid/jquery.bootgrid.min.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
Modificar Separacion
<?php echo $__env->make('separaciones.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<?php echo $__env->make('plantillas.mensajes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row">
  <?php echo $__env->make('separaciones.nuevo.tblProductos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('separaciones.modificar.frmAgregarProducto', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php echo $__env->make('separaciones.modificar.tblDetalles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('separaciones.modificar.frmSeparacion', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php echo e(Html::script('bootgrid/jquery.bootgrid.min.js')); ?>

<?php echo $__env->make('separaciones.nuevo.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.cajero', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>