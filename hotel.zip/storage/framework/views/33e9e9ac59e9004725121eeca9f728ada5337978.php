<?php $__env->startSection('estilos'); ?>
<?php echo e(Html::style('bootgrid/jquery.bootgrid.min.css')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
Descuentos Vencidos
<?php echo $__env->make('descuentos.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('descuentos.modales.nuevo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
  <?php echo $__env->make('plantillas.mensajes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
      <div class="table-responsive">
        <table class="table table-condensed table-hover table-bordered" id="tblDescuentos">
          <thead>
            <tr class="info">
              <th data-column-id="id" data-order="desc" style="text-align:center;">NÚMERO</th>
              <th data-column-id="tienda">TIENDA</th>
              <th data-column-id="conceptos">CONCEPTOS</th>
              <th data-column-id="porcentaje">PORCENTAJE</th>
              <th data-column-id="inicio">INICIO</th>
              <th data-column-id="final">FINAL</th>
              <th data-column-id="commands" data-formatter="commands" data-sortable="false">OPERACIONES</th>
            </tr>
          </thead>
        </table>
      </div>
    </div>
  </div>
  <?php echo $__env->make('descuentos.modales.editar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('descuentos.modales.eliminar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <?php echo e(Html::script('bootgrid/jquery.bootgrid.min.js')); ?>

  <?php echo $__env->make('descuentos.listarVencidos.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.administrador', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>